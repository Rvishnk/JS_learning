
let num=60;
if(num% 3==0){
console.log("multiple of 3")
}