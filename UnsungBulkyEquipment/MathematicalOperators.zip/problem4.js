

let database_user=" ravi4123";
let database_pass=" hometown2";

let user="ravi4123";
let pass=" hometown2";
if(database_user==user){
  if(database_pass==pass){
    console.log("login successful")
  }else{
    console.log("wrong credential")
  }
}
