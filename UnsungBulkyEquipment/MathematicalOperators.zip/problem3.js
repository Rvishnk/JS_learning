//Problem 3: Given 2 numbers a and b print which is greater or "both equal".
let a=20;
let b=10;
if(a>b){
  console.log("a is greater");
}else if(a==b){
  console.log ("both equal")
  
}